# Installation

Vous pouvez traviller sur Google collab, sinon, pour installer en local suivre ces instructions.

## Initialisation de conda

(Sur les machines Linux de l'IUT)

```bash
    /opt/anaconda3/bin/conda init
```

A près, fermer le terminal et en rouvrir un nouveau. Vous devriez voir un "(base)" dans le prompt.

## Creation d'un environnement

```bash
    conda create -n cours-ia python=3.9
```

## Activation de l'environnement


Vous pouvez lister les envionnements disponibles en faisant 

```bash
    conda env list
```

Pour activer l'environnement créé précédemment, faire :

```bash
    conda activate cours-ia
```
Vous devriez voir un "(cours-ia)" dans le prompt

## Installation des packages

Dans l'environnement créé, faire:

```bash
pip install numpy scikit-learn matplotlib seaborn jupyter ipykernel
```

# Utilisation des Jupyter notebook

Dans VS Code, installer les extensions Python et Jupyter.
Pour executer un jupyter notebook, il faudra selectionner la bonne version de python, celle de l'environnement conda.
